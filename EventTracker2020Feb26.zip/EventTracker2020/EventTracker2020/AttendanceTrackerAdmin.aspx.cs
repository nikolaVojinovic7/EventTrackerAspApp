﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventTracker2020
{
    public partial class AttendanceTracker : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if(Session["UserID"] != "admin")
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnDelete1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnDelete2_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnDelete3_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session["UserID"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}