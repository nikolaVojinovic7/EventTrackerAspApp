﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventTracker2020
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            if (String.Equals(txtUsername.Text, "admin@isp.net") && String.Equals(txtPassword.Text, "admin"))
            {
                Session["UserID"] = "admin";
                Server.Transfer("AttendanceTrackerAdmin.aspx");

            }
            else if (String.Equals(txtUsername.Text, "eventorg@isp.net") && String.Equals(txtPassword.Text, "eventorg"))
            {
                Session["UserID"] = "eventorg";
                Server.Transfer("Registers.aspx");

            }
            else if (txtUsername.Text == "" && txtPassword.Text == "")
            {

            }
            else
            {
                lblMessage.Text = "Incorrect Username and Password.";

            }
            txtUsername.Text = "";
        }

        protected void Register_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("ResetPassword.aspx");
        }
    }
}