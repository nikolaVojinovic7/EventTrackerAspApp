﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventTracker2020
{
    public partial class NewScheme : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["UserID"] != "eventorg")
            {
                Response.Redirect("Login.aspx");
            }
        
            if (IsPostBack)
            {
                if (rangeValAddSessions.IsValid && txtAddSession.Text != "")
                {
                    int newSessions = int.Parse(txtAddSession.Text);
                    int SessionCount = 3;

                    if (newSessions > 17)
                    {
                        return;
                    }

                    for (int i = 0; i < newSessions; i++)
                    {
                        TableRow row = new TableRow();
                        TableCell sessNum = new TableCell();
                        TableCell sessSymbol = new TableCell();
                        TableCell sessStatusName = new TableCell();
                        TableCell sessAssigned = new TableCell();
                        TableCell sessOrder = new TableCell();
                        TableCell sessDelete = new TableCell();

                        Label newSessNum = new Label();
                        newSessNum.Text = (SessionCount + 1).ToString();
                        TextBox txtsessSymbol = new TextBox();
                        TextBox txtSessStatusName = new TextBox();
                        TextBox txtSessAssigned = new TextBox();
                        DropDownList dropSessOrder = new DropDownList();
                        dropSessOrder.Items.Add("1");
                        dropSessOrder.Items.Add("2");
                        dropSessOrder.Items.Add("3");

                        ImageButton btnSessDelete = new ImageButton();
                        btnSessDelete.ImageUrl = "img/trash.png";

                        row.ID = "newRow" + i;
                        sessNum.ID = "newSessNum" + i;
                        txtsessSymbol.ID = "newSessSymbol" + i;
                        txtSessStatusName.ID = "newSessStatusName" + i;
                        txtSessAssigned.ID = "newSessAssigned" + i;
                        dropSessOrder.ID = "newOrderSess" + i;
                        btnSessDelete.ID = "newDeleteSess" + i;

                        sessNum.Controls.Add(newSessNum);
                        sessSymbol.Controls.Add(txtsessSymbol);
                        sessStatusName.Controls.Add(txtSessStatusName);
                        sessAssigned.Controls.Add(txtSessAssigned);
                        sessOrder.Controls.Add(dropSessOrder);
                        sessDelete.Controls.Add(btnSessDelete);

                        row.Cells.Add(sessNum);
                        row.Cells.Add(sessSymbol);
                        row.Cells.Add(sessStatusName);
                        row.Cells.Add(sessAssigned);
                        row.Cells.Add(sessOrder);
                        row.Cells.Add(sessDelete);

                        tblSessions.Rows.Add(row);
                        SessionCount++;
                    }
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AttendanceSchemes.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session["UserID"] = null;
            Response.Redirect("Login.aspx");
        }

        protected void btnAddSession_Click(object sender, ImageClickEventArgs e)
        {
           
        }
    }
}