﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventTracker2020
{
    public partial class AttendanceSchemes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["UserID"] != "eventorg")
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session["UserID"] = null;
            Response.Redirect("Login.aspx");
        }

        protected void btnNewScheme_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewScheme.aspx");
        }

        protected void btnSetDefaultBottom_Click(object sender, EventArgs e)
        {
            lblCurrentDefaultTop.Visible = false;
            btnSetDefaultTop.Visible = true;
            lblCurrentDefaultBottom.Visible = true;
            btnSetDefaultBottom.Visible = false;
        }

        protected void btnSetDefaultTop_Click(object sender, EventArgs e)
        {
            lblCurrentDefaultTop.Visible = true;
            btnSetDefaultTop.Visible = false;
            lblCurrentDefaultBottom.Visible = false;
            btnSetDefaultBottom.Visible = true;
        }
    }
}