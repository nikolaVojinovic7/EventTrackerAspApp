﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EventTracker2020
{
    public partial class AddRegisters : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (Session["UserID"] != "eventorg")
            {
                Response.Redirect("Login.aspx");
            }
            if (IsPostBack)
            {
                if(rangeValAddSessions.IsValid && txtAddSession.Text != "")
                {

                    int newSessions = int.Parse(txtAddSession.Text);
                    int SessionCount = 3;

                    if(newSessions > 17)
                    {
                        return;
                    }
                    for (int i = 0; i < newSessions; i++)
                    {
                        TableRow row = new TableRow();
                        TableCell sessNum = new TableCell();
                        TableCell sessName = new TableCell();
                        TableCell sessDescription = new TableCell();
                        TableCell sessOrder = new TableCell();
                        TableCell sessDelete = new TableCell();

                        Label newSessNum = new Label();
                        newSessNum.Text = (SessionCount + 1).ToString();
                        TextBox txtsessName = new TextBox();
                        TextBox txtSessDescription = new TextBox();
                        DropDownList dropSessOrder = new DropDownList();
                        dropSessOrder.Items.Add("1");
                        dropSessOrder.Items.Add("2");
                        dropSessOrder.Items.Add("3");

                        ImageButton btnSessDelete = new ImageButton();
                        btnSessDelete.ImageUrl = "img/trash.png";

                        row.ID = "newRow" + i;
                        sessNum.ID = "newSessNum" + i;
                        txtsessName.ID = "newSessName" + i;
                        txtSessDescription.ID = "newSessDescription" + i;
                        dropSessOrder.ID = "newOrderSess" + i;
                        btnSessDelete.ID = "newDeleteSess" + i;

                        sessNum.Controls.Add(newSessNum);
                        sessName.Controls.Add(txtsessName);
                        sessDescription.Controls.Add(txtSessDescription);
                        sessOrder.Controls.Add(dropSessOrder);
                        sessDelete.Controls.Add(btnSessDelete);

                        row.Cells.Add(sessNum);
                        row.Cells.Add(sessName);
                        row.Cells.Add(sessDescription);
                        row.Cells.Add(sessOrder);
                        row.Cells.Add(sessDelete);

                        tblSessions.Rows.Add(row);
                        SessionCount++;
                    }
                }
            }

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registers.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session["UserID"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}